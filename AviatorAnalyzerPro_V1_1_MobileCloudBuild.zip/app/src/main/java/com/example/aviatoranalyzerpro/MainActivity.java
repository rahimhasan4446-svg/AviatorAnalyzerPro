package com.example.aviatoranalyzerpro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.io.IOException;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 4101;
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface public void chooseScreenshot() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(intent, PICK_IMAGE);
            });
        }
        @JavascriptInterface public void saveTextToApp(String text) {
            runOnUiThread(() -> web.evaluateJavascript(
                "window.onOcrResult(" + org.json.JSONObject.quote(text) + ")", null));
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try {
                InputImage image = InputImage.fromFilePath(this, uri);
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image)
                    .addOnSuccessListener(result -> web.evaluateJavascript(
                        "window.onOcrResult(" +
                        org.json.JSONObject.quote(result.getText()) + ")", null))
                    .addOnFailureListener(e -> web.evaluateJavascript(
                        "window.onOcrResult('OCR failed: " +
                        org.json.JSONObject.quote(String.valueOf(e.getMessage())) + "')", null));
            } catch (IOException e) {
                web.evaluateJavascript("window.onOcrResult('Could not open selected image')", null);
            }
        }
    }
}
