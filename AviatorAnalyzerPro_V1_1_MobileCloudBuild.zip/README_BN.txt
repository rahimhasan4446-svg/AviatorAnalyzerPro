AVIATOR ANALYZER PRO — Sample V1.1 (Android Studio source)

এই Sample ভার্সনে:
- Screenshot Import: ব্যবহারকারী নিজে screenshot নির্বাচন করবেন।
- OCR: ছবির দৃশ্যমান লেখা পড়ার চেষ্টা করবে (Google ML Kit Text Recognition)।
- Historical Round Entry: OCR থেকে পাওয়া লেখা দেখে ব্যবহারকারী নিজে Round ID, Decimal, multiplier ইত্যাদি যাচাই করে সংরক্ষণ করবেন।
- Experimental SHA-512 verifier: Server Seed + N1 + N2 + N3 ক্রমে concatenate করে SHA-512 তৈরি করে। এই নিয়মটি ব্যবহারকারীর দেওয়া দাবির ভিত্তিতে পরীক্ষামূলক; অফিসিয়াল SPRIBE সূত্র হিসেবে যাচাইকৃত নয়।
- Decimal/Multiplier calculator: প্রদত্ত 97% RTP সূত্রটি পরীক্ষামূলকভাবে প্রয়োগ করে।
- Local database: Android WebView localStorage-এ ডেটা থাকে; অ্যাপের ডেটা মুছলে রেকর্ড হারাতে পারে।
- JSON export.

সীমাবদ্ধতা:
- Live screen capture/continuous monitoring নেই।
- অন্য অ্যাপের private data পড়া হয় না।
- Betting, auto-bet বা future-round prediction নেই।
- APK এই পরিবেশে compile/sign করে পরীক্ষা করা হয়নি; এটি Android Studio source project।

চালানোর ধাপ:
1. ZIP extract করুন।
2. Android Studio > Open > AviatorAnalyzerPro_V1_1 নির্বাচন করুন।
3. Gradle Sync করুন (ইন্টারনেট লাগবে, ML Kit dependency download হবে)।
4. Run চাপুন। ফোনে USB debugging অথবা emulator ব্যবহার করুন।
5. Screenshot Import বাটনে চাপ দিয়ে পুরোনো রাউন্ডের screenshot বেছে নিন।
6. OCR text দেখে তথ্যগুলো নিজে যাচাই করে form-এ দিন; OCR ভুল পড়তে পারে।

Hash verification:
- ইনপুটগুলো সম্পূর্ণ ও সঠিক হতে হবে।
- Hash মিললে সেটি কেবল ওই concatenation hypothesis-এর সঙ্গে মিল; অফিসিয়াল fairness proof নয়।
- Server Seed commitment (যেমন SHA-256) আলাদা করে যাচাই করতে হলে official documented commitment format দরকার।

Cloud APK Build (মোবাইল দিয়েও করা যাবে):
1. GitHub-এ নতুন Public বা Private repository তৈরি করুন।
2. ZIP extract করে সব project files repository-তে upload করুন; root-এ settings.gradle ও app/ থাকতে হবে।
3. Commit করুন। Actions tab খুলুন।
4. 'Build Aviator Analyzer Pro APK' workflow চালু হবে (অথবা Actions থেকে Run workflow চাপুন)।
5. সফল হলে workflow run-এর নিচে Artifacts থেকে AviatorAnalyzerPro-debug-apk.zip download করুন।
6. ZIP extract করে app-debug.apk ফোনে ইনস্টল করুন। Android চাইলে unknown apps install permission দিতে হবে।
এই build workflow ক্লাউডে APK তৈরি করে; এই source environment নিজে APK compile করেনি।
